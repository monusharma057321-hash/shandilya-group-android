# Shandilya Group Native Android App

This is a native Android Java application (not a WebView/site wrapper).

## Build
GitHub Actions builds `:app:assembleDebug` on every push to `main` or by manually running **Build Shandilya Group Native APK** from the Actions tab.

APK artifact: `Shandilya-Group-Native-APK`.

## Kundli API
The Kundli form resolves the entered birthplace to latitude/longitude using Android Geocoder and sends a POST JSON request to:
`https://shandilya-kundli-api.monusharma057321.workers.dev/`

Fields sent: `year`, `month`, `date`, `hours`, `minutes`, `latitude`, `longitude`, `timezone` (5.5).

The API's response is shown in the app. Confirm the Worker response schema before building chart-specific screens; this project does not expose any secret API key in the APK.
