package com.shandilyagroup.astrology;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final int navy=Color.rgb(7,27,73), navy2=Color.rgb(12,42,95), gold=Color.rgb(224,183,91), white=Color.WHITE;
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private LinearLayout root;
    private EditText nameInput,dateInput,timeInput,placeInput;
    private TextView resultView, submitView;
    private static final String API_URL="https://shandilya-kundli-api.monusharma057321.workers.dev/";

    @Override public void onCreate(Bundle state){super.onCreate(state);getWindow().setStatusBarColor(navy);getWindow().setNavigationBarColor(navy);showHome();}
    private void prepare(String title){
        ScrollView scroll=new ScrollView(this); scroll.setBackgroundColor(navy);
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(18),dp(16),dp(18),dp(24));scroll.addView(root);
        setContentView(scroll);
        TextView heading=text(title,22,gold,true);root.addView(heading);
    }
    private void showHome(){
        prepare("SG  •  Shandilya Group");
        TextView sub=text("ASTROLOGY  •  PUJA SERVICES",11,white,false);root.addView(sub);
        TextView greeting=text("नमस्कार 🙏",25,white,true);LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,-2);gp.topMargin=dp(28);root.addView(greeting,gp);
        root.addView(text("आपका ज्योतिष मार्गदर्शन",15,gold,false));
        LinearLayout hero=panel();hero.setOrientation(LinearLayout.VERTICAL);hero.addView(text("अपनी जन्म कुंडली जानें",20,gold,true));hero.addView(text("जन्म विवरण भरें और Cloudflare Kundli API से गणना प्राप्त करें",13,white,false));
        TextView cta=button("कुंडली बनाएँ  →");hero.addView(cta);LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(22);root.addView(hero,hp);cta.setOnClickListener(v->showKundli());
        TextView services=text("ज्योतिष सेवाएँ",19,gold,true);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.topMargin=dp(26);root.addView(services,sp);
        String[] labels={"कुंडली AI","कुंडली मिलान","दैनिक पंचांग","राशिफल","ग्रह और दशा","शुभ मुहूर्त","पूजा बुकिंग","ज्योतिष परामर्श"};
        for(String label:labels){TextView item=button(label);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(9);root.addView(item,p);item.setOnClickListener(v->{if(label.equals("कुंडली AI")||label.equals("ग्रह और दशा"))showKundli();else notice(label+" मॉड्यूल अभी तैयार किया जा रहा है।");});}
        TextView foot=text("Pt. Monu Sharma",13,gold,true);LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(-1,-2);fp.topMargin=dp(24);foot.setGravity(Gravity.CENTER);root.addView(foot,fp);
    }
    private void showKundli(){
        prepare("जन्म कुंडली");
        TextView back=text("← होम",14,gold,true);root.addView(back);back.setOnClickListener(v->showHome());
        root.addView(text("अपना सही जन्म विवरण भरें।",13,white,false));
        nameInput=field("पूरा नाम");dateInput=field("जन्म तारीख (YYYY-MM-DD)");timeInput=field("जन्म समय (HH:MM, 24 घंटे)");placeInput=field("जन्म स्थान (शहर, राज्य, देश)");
        dateInput.setHint("उदाहरण: 1989-05-03");timeInput.setHint("उदाहरण: 07:30");placeInput.setHint("उदाहरण: Neem Ka Thana, Rajasthan, India");
        root.addView(nameInput);root.addView(dateInput);root.addView(timeInput);root.addView(placeInput);
        submitView=button("कुंडली बनाएँ");LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.topMargin=dp(14);root.addView(submitView,bp);
        resultView=text("कुंडली का परिणाम यहाँ दिखाई देगा।",13,white,false);LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,-2);rp.topMargin=dp(16);root.addView(resultView,rp);
        submitView.setOnClickListener(v->submitKundli());
    }
    private void submitKundli(){
        String nm=nameInput.getText().toString().trim(), ds=dateInput.getText().toString().trim(), ts=timeInput.getText().toString().trim(), place=placeInput.getText().toString().trim();
        if(nm.isEmpty()||ds.isEmpty()||ts.isEmpty()||place.isEmpty()){notice("कृपया सभी जन्म विवरण भरें।");return;}
        final int year,month,day,hour,minute;
        try{String[] d=ds.split("-");String[] t=ts.split(":");if(d.length!=3||t.length<2)throw new Exception();year=Integer.parseInt(d[0]);month=Integer.parseInt(d[1]);day=Integer.parseInt(d[2]);hour=Integer.parseInt(t[0]);minute=Integer.parseInt(t[1]);if(month<1||month>12||day<1||day>31||hour<0||hour>23||minute<0||minute>59)throw new Exception();}
        catch(Exception e){notice("तारीख YYYY-MM-DD और समय HH:MM में भरें।");return;}
        submitView.setEnabled(false);submitView.setText("कुंडली बनाई जा रही है...");resultView.setText("जन्म स्थान के coordinates खोजे जा रहे हैं...");
        executor.execute(()->{
            try{
                Geocoder geocoder=new Geocoder(this,Locale.getDefault());
                List<Address> found=geocoder.getFromLocationName(place,1);
                if(found==null||found.isEmpty()||!found.get(0).hasLatitude()||!found.get(0).hasLongitude())throw new Exception("जन्म स्थान नहीं मिला। कृपया शहर और राज्य का नाम सही लिखें।");
                Address a=found.get(0);double lat=a.getLatitude(),lon=a.getLongitude();
                JSONObject body=new JSONObject();body.put("year",year);body.put("month",month);body.put("date",day);body.put("hours",hour);body.put("minutes",minute);body.put("latitude",lat);body.put("longitude",lon);body.put("timezone",5.5);
                HttpURLConnection c=(HttpURLConnection)new URL(API_URL).openConnection();c.setRequestMethod("POST");c.setConnectTimeout(20000);c.setReadTimeout(30000);c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=UTF-8");c.setRequestProperty("Accept","application/json");
                try(OutputStream os=c.getOutputStream()){os.write(body.toString().getBytes("UTF-8"));}
                int code=c.getResponseCode();InputStream stream=(code>=200&&code<400)?c.getInputStream():c.getErrorStream();StringBuilder response=new StringBuilder();
                try(BufferedReader br=new BufferedReader(new InputStreamReader(stream,"UTF-8"))){String line;while((line=br.readLine())!=null)response.append(line).append('\n');}
                c.disconnect();String output=response.toString();if(code<200||code>=300)throw new Exception("API त्रुटि (HTTP "+code+"): "+output);
                JSONObject json=new JSONObject(output);String pretty=json.toString(2);
                runOnUiThread(()->{resultView.setText("कुंडली API सफल!\nस्थान: "+place+"\nLatitude: "+lat+"\nLongitude: "+lon+"\n\nAPI परिणाम:\n"+pretty);submitView.setEnabled(true);submitView.setText("कुंडली फिर से बनाएँ");});
            }catch(Exception e){String msg=e.getMessage()==null?"अज्ञात त्रुटि":e.getMessage();runOnUiThread(()->{resultView.setText("कुंडली नहीं बन पाई।\n"+msg);submitView.setEnabled(true);submitView.setText("दोबारा कोशिश करें");});}
        });
    }
    private EditText field(String hint){EditText e=new EditText(this);e.setSingleLine(true);e.setTextColor(white);e.setHintTextColor(Color.LTGRAY);e.setHint(hint);e.setTextSize(15);e.setPadding(dp(13),dp(10),dp(13),dp(10));GradientDrawable bg=new GradientDrawable();bg.setColor(navy2);bg.setCornerRadius(dp(10));bg.setStroke(dp(1),gold);e.setBackground(bg);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.topMargin=dp(10);root.addView(new View(this),new LinearLayout.LayoutParams(0,0));return e;}
    private LinearLayout panel(){LinearLayout l=new LinearLayout(this);l.setPadding(dp(16),dp(16),dp(16),dp(16));GradientDrawable b=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,new int[]{navy2,Color.rgb(28,62,119)});b.setCornerRadius(dp(17));b.setStroke(dp(1),gold);l.setBackground(b);return l;}
    private TextView button(String s){TextView t=text(s,15,navy,true);t.setGravity(Gravity.CENTER);t.setPadding(dp(14),dp(13),dp(14),dp(13));GradientDrawable b=new GradientDrawable();b.setColor(gold);b.setCornerRadius(dp(12));t.setBackground(b);return t;}
    private TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    private void notice(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    private int dp(int x){return (int)(x*getResources().getDisplayMetrics().density+0.5f);}
    @Override protected void onDestroy(){super.onDestroy();executor.shutdown();}
}
