package com.shandilyagroup.astrology;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int navy = Color.rgb(7, 27, 73);
    private final int navy2 = Color.rgb(12, 42, 95);
    private final int gold = Color.rgb(224, 183, 91);
    private final int white = Color.WHITE;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(navy);
        getWindow().setNavigationBarColor(navy);
        getWindow().getDecorView().setSystemUiVisibility(0);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(navy);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(16), dp(18), dp(18));
        scroll.addView(root);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView logo = new TextView(this);
        logo.setText("SG");
        logo.setTextColor(navy);
        logo.setTextSize(21);
        logo.setTypeface(null, Typeface.BOLD);
        logo.setGravity(Gravity.CENTER);
        GradientDrawable badge = new GradientDrawable();
        badge.setColor(gold); badge.setShape(GradientDrawable.OVAL);
        logo.setBackground(badge);
        top.addView(logo, new LinearLayout.LayoutParams(dp(52), dp(52)));

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        brand.setPadding(dp(12), 0, 0, 0);
        TextView name = text("Shandilya Group", 20, gold, true);
        TextView sub = text("ASTROLOGY • PUJA SERVICES", 10, white, false);
        brand.addView(name); brand.addView(sub);
        top.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        top.addView(text("⌕     ♧", 25, gold, true));
        root.addView(top);

        TextView greeting = text("नमस्कार 🙏", 24, white, true);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-1, -2);
        gp.topMargin = dp(28); root.addView(greeting, gp);
        root.addView(text("आपका आज का ज्योतिष मार्गदर्शन", 14, gold, false));

        LinearLayout hero = new LinearLayout(this);
        hero.setOrientation(LinearLayout.VERTICAL);
        hero.setPadding(dp(18), dp(18), dp(18), dp(18));
        GradientDrawable heroBg = new GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT, new int[]{navy2, Color.rgb(28, 62, 119)});
        heroBg.setCornerRadius(dp(18)); heroBg.setStroke(dp(1), gold);
        hero.setBackground(heroBg);
        TextView h1 = text("अपनी जन्म कुंडली जानें", 20, gold, true);
        TextView h2 = text("जन्म विवरण से अपनी कुंडली और ग्रह स्थिति देखें", 13, white, false);
        TextView cta = text("कुंडली बनाएँ  →", 14, navy, true);
        cta.setGravity(Gravity.CENTER); cta.setPadding(dp(14), dp(10), dp(14), dp(10));
        GradientDrawable ctaBg = new GradientDrawable(); ctaBg.setColor(gold); ctaBg.setCornerRadius(dp(12));
        cta.setBackground(ctaBg);
        hero.addView(h1); hero.addView(h2);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, -2);
        cp.topMargin = dp(14); hero.addView(cta, cp);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = dp(20); root.addView(hero, hp);
        cta.setOnClickListener(v -> notice("कुंडली मॉड्यूल अगले चरण में जोड़ा जाएगा।"));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        TextView services = text("ज्योतिष सेवाएँ", 19, gold, true);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.topMargin = dp(24); root.addView(services, tp);

        String[][] items = {
            {"☸", "कुंडली AI"}, {"♡", "कुंडली मिलान"},
            {"☀", "दैनिक पंचांग"}, {"✦", "राशिफल"},
            {"♙", "ग्रह और दशा"}, {"◷", "शुभ मुहूर्त"},
            {"ॐ", "पूजा बुकिंग"}, {"✆", "ज्योतिष परामर्श"}
        };
        for (int i=0; i<items.length; i+=2) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.addView(serviceCard(items[i][0], items[i][1]), new LinearLayout.LayoutParams(0, dp(112), 1));
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(0, dp(112), 1);
            rp.leftMargin = dp(10);
            row.addView(serviceCard(items[i+1][0], items[i+1][1]), rp);
            LinearLayout.LayoutParams rowp = new LinearLayout.LayoutParams(-1, -2);
            rowp.topMargin = dp(10); root.addView(row, rowp);
        }

        TextView ai = text("✧  Shandilya AI ज्योतिषी", 18, gold, true);
        LinearLayout.LayoutParams aip = new LinearLayout.LayoutParams(-1, -2);
        aip.topMargin = dp(24); root.addView(ai, aip);
        root.addView(text("अपने ज्योतिष संबंधी सवाल पूछें", 13, white, false));

        TextView ask = text("अपना सवाल पूछें  →", 14, navy, true);
        ask.setGravity(Gravity.CENTER); ask.setPadding(dp(14), dp(13), dp(14), dp(13));
        GradientDrawable askBg = new GradientDrawable(); askBg.setColor(gold); askBg.setCornerRadius(dp(14));
        ask.setBackground(askBg);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, -2);
        ap.topMargin = dp(12); root.addView(ask, ap);
        ask.setOnClickListener(v -> notice("AI ज्योतिषी सुविधा अगले चरण में जोड़ी जाएगी।"));

        TextView footer = text("होम          AI ज्योतिषी          लाइव          पूछें          प्रोफ़ाइल", 11, gold, true);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(54));
        fp.topMargin = dp(24); root.addView(footer, fp);

        setContentView(scroll);
    }

    private View serviceCard(String icon, String label) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(navy2); bg.setCornerRadius(dp(16)); bg.setStroke(dp(1), gold);
        card.setBackground(bg);
        TextView symbol = text(icon, 27, gold, true);
        symbol.setGravity(Gravity.CENTER);
        TextView title = text(label, 14, white, true);
        title.setGravity(Gravity.CENTER);
        card.addView(symbol); card.addView(title);
        card.setOnClickListener(v -> notice(label + " सुविधा अगले चरण में जोड़ी जाएगी।"));
        return card;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }
    private void notice(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
    private int dp(int x) { return (int)(x * getResources().getDisplayMetrics().density + 0.5f); }
}
